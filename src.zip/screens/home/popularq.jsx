import React, { useState } from "react";
import "./popularq.css";
import { TiArrowRight } from "react-icons/ti";
import { apiCallNew } from "../../networkcall/apiservises";
import ApiEndPoints from "../../networkcall/Apiendpoint";
import { useNavigate } from "react-router-dom";

const Popularq = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState([]);
  const [error, setError] = useState("");
  const [showModal, setShowModal] = useState(false);

  const handleShowData = async () => {
    setLoading(true);
    setError("");
    setShowModal(true);

    try {
      const response = await apiCallNew("get", null, ApiEndPoints.CateList);
      if (response.code === 200) {
        setData(response.result);
        console.log("Fetched data:", response.result);
      } else {
        setError("Failed to fetch data: " + response.status);
      }
    } catch (error) {
      setError("Error fetching categories: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  const passData = (id) => {
    navigate(`/pricingplans/${id}`);
    setShowModal(false);
  };

  const handleCloseModal = () => setShowModal(false);

  return (
    <>
      <div className="custom-quiz-section">
        <div className="custom-container">
          <div className="custom-row align-items-center">
            <div className="custom-col-md-6">
              <h1 className="font-effect-outline">Quiz</h1>
              <h2 className="custom-quiz-subheading">Explore Popular Quiz</h2>
            </div>
            <div className="custom-col-md-6 d-flex justify-content-end">
              <button className="custom-about-button" onClick={handleShowData}>
                More
                <TiArrowRight />
              </button>
            </div>
          </div>

          {/* Modal content */}
          {showModal && (
            <div className="custom-modal-overlay">
              <div className="custom-modal-content">
                <span className="close-btn" onClick={handleCloseModal}>
                  &times;
                </span>

                <div className="custom-data-display">
                  {loading ? (
                    <p>Loading...</p>
                  ) : error ? (
                    <p>{error}</p>
                  ) : (
                    <div className="button-container">
                      {data.map((item, index) => (
                        <button
                          key={index}
                          className="togglebar-button"
                          onClick={() => passData(item.category_id)}
                        >
                          {item.title}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default Popularq;
