import React, { useEffect, useState } from "react";
import "./About.css";
import { Link } from "react-router-dom";
import { apiCallNew } from "../../networkcall/apiservises";
import ApiEndPoints from "../../networkcall/Apiendpoint";

const About = () => {
  const [aboutData, setAboutData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchAboutData = async () => {
      try {
        const response = await apiCallNew("get", null, ApiEndPoints.About);
        if (response.status === 200) {
          const aboutInfo = response.data.find(
            (item) => item.slug === "about-us"
          );
          setAboutData(aboutInfo);
        } else {
          throw new Error("Failed to fetch about data");
        }
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };
    fetchAboutData();
  }, []);

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>Error: {error}</div>;
  }

  if (!aboutData) {
    return <div>No about data available.</div>;
  }

  const parser = new DOMParser();
  const htmlDoc = parser.parseFromString(aboutData.short_desc, "text/html");
  const heading = htmlDoc.querySelector("h3");
  const paragraph = htmlDoc.querySelector("p");
  const buttonLink = htmlDoc.querySelector("a");

  return (
    <div className="about-container">
      <div className="row">
        <div className="about-image-section col-md-6">
          <img
            src={`https://www.secrets4exams.com/images/pages/${aboutData.image}`}
            alt="Medical professionals"
            className="about-image"
          />
        </div>
        <div className="about-text-section col-md-6">
          <link
            rel="stylesheet"
            href="https://fonts.googleapis.com/css?family=Sofia&effect=neon|outline|emboss|shadow-multiple"
          />
          <h1 className="font-effect-outline">{aboutData.name}</h1>
          {heading && <h1 className="about-subtitle">{heading.innerHTML}</h1>}

          {paragraph && (
            <p className="about-description">{paragraph.innerHTML}</p>
          )}

          {buttonLink && (
            <Link
              // to={buttonLink.getAttribute("href") || "/aboutus"}
              to="/aboutus"
              className="about-button"
            >
              {buttonLink.textContent || "AboutUs"}
            </Link>
          )}
        </div>
      </div>
    </div>
  );
};

export default About;
