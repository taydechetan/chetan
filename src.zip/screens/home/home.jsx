import React, { useEffect, useState } from "react";
import "./Home.css";
import { Container, Row, Col, Button, Modal } from "react-bootstrap";
import { FaArrowRightLong } from "react-icons/fa6";
import About from "./about";
import Popularq from "./popularq";
import Carousal from "./carousal";
import Profile from "./Profile";
import { apiCallNew } from "../../networkcall/apiservises";
import ApiEndPoints from "../../networkcall/Apiendpoint";
import { useNavigate } from "react-router-dom";

const Home = () => {
  const navigate = useNavigate();
  const [showModal, setShowModal] = useState(false);
  const [data, setData] = useState("");
  const [loading, setLoading] = useState(false);
  const [examData, setExamData] = useState([]);
  const [error, setError] = useState(null);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const handleShowModal = async () => {
    setLoading(true);
    setError("");
    setShowModal(true);

    try {
      const response = await apiCallNew("get", null, ApiEndPoints.CateList);
      if (response.code === 200) {
        setData(response.result);
        console.log("Fetched data:", response.result);
      } else {
        setError("Failed to fetch data: " + response.status);
      }
    } catch (error) {
      setError("Error fetching categories: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleCloseModal = () => {
    setShowModal(false);
    setExamData([]);
    setError(null);
  };

  const passData = (id) => {
    navigate(`/pricingplans/${id}`);
    setShowModal(false);
  };

  return (
    <>
      <div className="custom-hero-section">
        <Container>
          <Row className="align-items-center">
            <Col md={6}>
              <div className="custom-hero-text">
                <h6 className="custom-hero-subtitle">Education Quiz</h6>
                <h1 className="custom-hero-title">
                  Get the Fastest Advantage!
                </h1>
                <p className="custom-hero-description">
                  Prepare with us to enhance your chances of succeeding in your
                  next medical exam.
                </p>

                <button className="selectbutton" onClick={handleShowModal}>
                  Select exam
                  <FaArrowRightLong className="m-1" />
                </button>
              </div>
            </Col>
            <Col md={6}>
              <div className="custom-hero-image-container"></div>
            </Col>
          </Row>
        </Container>
      </div>

      <About />
      <Popularq />
      <Carousal />
      <Profile />

      <Modal show={showModal} onHide={handleCloseModal} size="lg" centered>
        <Modal.Header closeButton>
          <Modal.Title>Select Your Exam</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {showModal && (
            <div className="custom-modal-overlay">
              <div className="custom-modal-content">
                <span className="closebtnnh " onClick={handleCloseModal}>
                  &times;
                </span>

                <div className="custom-data-display">
                  {loading ? (
                    <p>Loading...</p>
                  ) : error ? (
                    <p>{error}</p>
                  ) : (
                    <div className="button-container">
                      {data.map((item, index) => (
                        <button
                          key={index}
                          className="togglebar-button"
                          onClick={() => passData(item.category_id)}
                        >
                          {item.title}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleCloseModal}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
};

export default Home;
