import React, { useEffect, useRef, useState } from "react";
import { Container, Row, Col, Image, Carousel } from "react-bootstrap";
import { FaArrowLeft, FaArrowRight } from "react-icons/fa";
import "./Carousal.css";
import ApiEndPoints from "../../networkcall/Apiendpoint";
import { apiCallNew } from "../../networkcall/apiservises";
import { useParams } from "react-router-dom";

const Carousal = () => {
  const { id } = useParams();
  const carouselRef = useRef(null);
  const [carousal, setcarousal] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    concarousal(id);
  }, [id]);

  const concarousal = async () => {
    try {
      const response = await apiCallNew("get", null, ApiEndPoints.Carousal);
      if (response.status == 200) {
        setcarousal(response.data);
        // console.log("Fetched carousal data:", response.data);
      } else {
        setError("Failed to fetch carousal data: " + response.statusText);
      }
    } catch (error) {
      setError("Failed to fetch carousal data: " + error.message);
    }
  };

  const handlePrev = () => {
    if (carouselRef.current) {
      carouselRef.current.prev();
    }
  };

  const handleNext = () => {
    if (carouselRef.current) {
      carouselRef.current.next();
    }
  };

  const removeHtmlTags = (str) => {
    return str.replace(/<\/?[^>]+(>|$)/g, "");
  };

  return (
    <>
      <Container
        fluid
        className="testimonial-wrapper d-flex flex-column justify-content-center align-items-center"
      >
        <Row className="testimonial-card p-4">
          <Col xs={12}>
            <Carousel
              ref={carouselRef}
              controls={false}
              indicators={false}
              className="carousel-custom"
            >
              {carousal.map((item) => (
                <Carousel.Item key={item.id}>
                  <Col xs={12} className="text-center">
                    {item.image}
                    <Image
                      src={item.image}
                      className="testimonial-avatar"
                      alt="image"
                      onError={(e) => {
                        e.target.onerror = null;
                      }}
                      style={{ width: "100%", height: "auto" }}
                    />
                  </Col>
                  <Col xs={12} className="text-center mt-3">
                    <p className="testimonial-message">
                      {removeHtmlTags(item.description)}
                    </p>
                    <h5 className="testimonial-author mt-3">{item.name}</h5>
                  </Col>
                </Carousel.Item>
              ))}
            </Carousel>
          </Col>
        </Row>

        <div className="mt-3">
          <button
            style={{
              backgroundColor: "#44bd79",
              color: "white",
              border: "none",
              padding: "5px 10px",
            }}
            onClick={handlePrev}
          >
            <FaArrowLeft />
          </button>
          <button
            className="ms-3"
            style={{
              backgroundColor: "#44bd79",
              color: "white",
              border: "none",
              padding: "5px 10px",
            }}
            onClick={handleNext}
          >
            <FaArrowRight />
          </button>
        </div>
      </Container>
    </>
  );
};

export default Carousal;
