// import React, { useState } from "react";
// import "./ForgetPassword.css";
// import axios from "axios";
// import { useNavigate } from "react-router-dom";
// import { toast, ToastContainer } from "react-toastify";
// import "react-toastify/dist/ReactToastify.css";

// const ForgetPassword = () => {
//   const navigate = useNavigate();
//   const [email, setEmail] = useState("");
//   const [emailError, setEmailError] = useState("");
//   const [error, setError] = useState("");
//   const [otp, setOtp] = useState("");

//   const handleSubmit = async (e) => {
//     e.preventDefault();

//     setEmailError("");
//     setError("");

//     if (email.trim() === "") {
//       setEmailError("Please enter your email");
//       return;
//     }

//     const payload = { email: email.trim(), remember_token: otp };

//     try {
//       const response = await axios.post(
//         "http://nodejs.aercjbp.com/forgetPassword",
//         payload
//       );

//       if (response.status === 200) {
//         toast.success("Password reset link sent to your email.");
//         localStorage.setItem("forgottenEmail", email.trim());
//         setEmail("");
//       } else {
//         setError("Failed to send reset link: " + response.statusText);
//         toast.error("Failed to send reset link.");
//       }
//     } catch (error) {
//       setError("Failed to send reset link: " + error.message);
//       toast.error("An error occurred: " + error.message);
//     }
//   };

//   return (
//     <div className="forget-password-container">
//       <h2 className="forget-password-heading">Forget Password?</h2>
//       <form className="forget-password-form" onSubmit={handleSubmit}>
//         <input
//           type="email"
//           className="forget-password-input"
//           placeholder="Email Address"
//           value={email}
//           onChange={(e) => setEmail(e.target.value)}
//         />
//         {emailError && (
//           <p className="forget-password-error text-danger">{emailError}</p>
//         )}
//         <button type="submit" className="forget-password-button">
//           Send Password Reset Link
//         </button>
//       </form>
//       {error && <p className="forget-password-error text-danger">{error}</p>}
//       <ToastContainer />
//     </div>
//   );
// };

// export default ForgetPassword;

import React, { useState } from "react";
import "./ForgetPassword.css";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const ForgetPassword = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [emailError, setEmailError] = useState("");
  const [error, setError] = useState("");
  const [otp, setOtp] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();

    setEmailError("");
    setError("");

    if (email.trim() === "") {
      setEmailError("Please enter your email");
      return;
    }

    const payload = { email: email.trim(), remember_token: otp };

    try {
      const response = await axios.post(
        "http://nodejs.aercjbp.com/forgetPassword",
        payload
      );

      console.log(response.data);

      if (response.status === 200) {
        setOtp(response.data.otp);
        toast.success("OTP sent to your email. Check your inbox!");
        localStorage.setItem("forgottenEmail", email.trim());
        setEmail("");
        navigate("/verificationForm");
      } else {
        setError("Failed to send OTP: " + response.statusText);
        toast.error("Failed to send OTP.");
      }
    } catch (error) {
      setError("Failed to send OTP: " + error.message);
      toast.error("An error occurred: " + error.message);
    }
  };

  return (
    <div className="forget-password-container">
      <h2 className="forget-password-heading">Forget Password?</h2>
      <form className="forget-password-form" onSubmit={handleSubmit}>
        <input
          type="email"
          className="forget-password-input"
          placeholder="Email Address"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        {emailError && (
          <p className="forget-password-error text-danger">{emailError}</p>
        )}
        <button type="submit" className="forget-password-button">
          Send OTP
        </button>
      </form>
      {error && <p className="forget-password-error text-danger">{error}</p>}
      <ToastContainer />
    </div>
  );
};

export default ForgetPassword;

// import React, { useState } from "react";
// import "./ForgetPassword.css";
// import axios from "axios";
// import { useNavigate } from "react-router-dom";
// import { toast, ToastContainer } from "react-toastify";
// import "react-toastify/dist/ReactToastify.css";
// import { apiCallNew } from "../../networkcall/apiservises";
// import ApiEndPoints from "../../networkcall/Apiendpoint";

// const ForgetPassword = () => {
//   const navigate = useNavigate();
//   const [email, setEmail] = useState("");
//   const [emailError, setEmailError] = useState("");
//   const [error, setError] = useState("");
//   const [otp, setOtp] = useState("");

//   const handleSubmit = async (e) => {
//     e.preventDefault();

//     setEmailError("");
//     setError("");

//     if (email.trim() === "") {
//       setEmailError("Please enter your email");
//       return;
//     }

//     const payload = { email: email.trim(), remember_token: otp };

//     try {
//       const res = await apiCallNew(
//         "post",
//         payload,
//         ApiEndPoints.ForgetPassword
//       );
//       console.log(res);
//       if (res.status === 200) {
//         toast.success("Registration successful!");
//         setTimeout(() => {
//           navigate("/verificationForm");
//         }, 3000);
//       } else {
//         toast.error(res.errors[0].msg);
//       }
//     } catch (error) {
//       console.log(error);
//       toast.error(error[0]?.msg);
//     }
//   };

//   return (
//     <div className="forget-password-container">
//       <h2 className="forget-password-heading">Forget Password?</h2>
//       <form className="forget-password-form" onSubmit={handleSubmit}>
//         <input
//           type="email"
//           className="forget-password-input"
//           placeholder="Email Address"
//           value={email}
//           onChange={(e) => setEmail(e.target.value)}
//         />
//         {emailError && (
//           <p className="forget-password-error text-danger">{emailError}</p>
//         )}
//         <button type="submit" className="forget-password-button">
//           Send OTP
//         </button>
//       </form>
//       {error && <p className="forget-password-error text-danger">{error}</p>}
//       <ToastContainer />
//     </div>
//   );
// };

// export default ForgetPassword;
