import React, { useEffect, useState } from "react";
import "./startstudy.css";
import { apiCallNew } from "../../networkcall/apiservises";
import ApiEndPoints from "../../networkcall/Apiendpoint";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

const Startstuding = () => {
  const [subscriptions, setSubscriptions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const navigate = useNavigate();
  const handlesubmit = (item) => {
    console.log("G.g.", item);
    navigate("/Examcard", { state: { categoryData: item } });
  };
  useEffect(() => {
    const fetchSubscriptions = async () => {
      try {
        const token = localStorage.getItem("@userToken");

        if (!token) {
          throw new Error("No token found, please log in.");
        }

        const res = await fetch(ApiEndPoints.startStudying, {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
            Authorization: token,
          },
        });

        if (!res.ok) {
          const errorData = await res.json();
          const errorMessage =
            errorData.errors && errorData.errors[0]
              ? errorData.errors[0].msg
              : "Unknown error occurred.";
          throw new Error(errorMessage);
        }

        const data = await res.json();
        setSubscriptions(data.data || []);
        // toast.success("Data fetched successfully!");
      } catch (error) {
        // toast.error("Failed to fetch data.");
        setError(error.message || "An error occurred.");
      } finally {
        setLoading(false);
      }
    };

    fetchSubscriptions();
  }, []);

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>Error: {error}</div>;
  }

  return (
    <div className="subscriptions-container m-0">
      <div>
        <h2 className="headdingg m-0">Your Subscriptions</h2>
      </div>
      <div className="subscriptions-grid">
        {subscriptions.map((sub, index) => (
          <div
            key={index}
            className={`subscription-card ${index === 0 ? "large-card" : ""}`}
          >
            <h3>{sub.category_name}</h3>
            <p>Expires on: {sub.formattedExpiryDate}</p>
            <button onClick={() => handlesubmit(sub)} className="view-btn">
              View
            </button>
            <p
              className={
                sub.status === "active" ? "active-status" : "expired-status"
              }
            >
              {sub.status === "active"
                ? "Package is: Active"
                : "Package Is Expire! You Will Not Attend The Exam."}
            </p>
            {sub.status === "active" && index === 0 && (
              <button on className="view-btn btn-primary">
                View
              </button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default Startstuding;
