import React, { useState, useEffect } from "react";
import "./Examcard.css";
import ApiEndPoints from "../../networkcall/Apiendpoint";
import { useLocation, useNavigate } from "react-router-dom";

const ExamCard = () => {
  const [examData, setExamData] = useState([]);
  const location = useLocation();
  const cateData = location.state?.categoryData || {};

  const payload = {
    category_id: cateData.category_id,
    order_package_id: cateData.order_package_id,
    user_id: cateData.user_id,
    exam_id: cateData.exam_id,
  };
  console.log("Category Data:", cateData);
  console.log("exam_id", cateData.exam_id);
  useEffect(() => {
    const fetchExamData = async () => {
      try {
        const token = localStorage.getItem("@userToken");
        console.log("Token:", token);
        if (!token) {
          throw new Error("No token found, please log in.");
        }
        const response = await fetch(ApiEndPoints.subscriptionPackage, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: token,
          },
          body: JSON.stringify(payload),
        });

        // console.log("Response Status:", response.status);
        // console.log("Raw Response:", response);
        const data = await response.json();
        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(
            errorData.errors?.[0]?.msg || "Unknown error occurred."
          );
        }

        setExamData(data.data);
      } catch (error) {
        console.log("Error:", error);
      }
    };

    fetchExamData();
  }, []);

  const navigate = useNavigate();
  const handleStartExam = (exam) => {
    navigate("/Subcribeexam", {
      state: { exam_id: cateData.exam_id, examData: exam },
    });
  };

  return (
    <div className="exam-container m-0">
      <h1 className="exam-header">Your Exams</h1>
      <div className="exam-content m-2">
        {examData?.map((exam, index) => (
          <div className="exam-card" key={index}>
            <h2>{exam.title}</h2>
            <p>{exam.totalQue} Total Questions</p>
            <p>{exam.remaining_questions} Remaining Questions</p>
            <p>{exam.answered} Answered</p>
            <p>{exam.per_q_mark} marks per question</p>
            <p>{exam.duration} Duration</p>
            <button
              className="start-button"
              onClick={() => handleStartExam(exam)}
            >
              Start
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ExamCard;
