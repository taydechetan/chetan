import React, { useEffect, useState } from "react";
import "./login.css";
import { Container, Form, Button, Row, Col } from "react-bootstrap";
import { GoogleLogin } from "@react-oauth/google";
import { FcGoogle } from "react-icons/fc";
import { useGoogleLogin } from "@react-oauth/google";
import axios from "axios";
import { apiCallNew } from "../../networkcall/apiservises";
import ApiEndPoints from "../../networkcall/Apiendpoint";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { useNavigate } from "react-router-dom";
import { setToken, setUserData } from "../../helper/storage";
import { FaUserAlt, FaEye } from "react-icons/fa";
import { Link } from "react-router-dom";
import { FaEyeSlash } from "react-icons/fa";

function Login() {
  const navigate = useNavigate();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [showPassword, setShowPassword] = useState(false);
  const [usernameError, setUsernameError] = useState("");
  const [passwordError, setPasswordError] = useState("");

  const togglePaswity = () => {
    setShowPassword((prev) => !prev);
  };

  const handleSuccess = (response) => {
    console.log("Login Success:", response);
    toast.success("Login successful!");
    setTimeout(() => {
      navigate("/");
    }, 3000);
  };

  const handleError = (error) => {
    console.log("Login Error:", error);
    toast.error("Login failed!");
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setUsernameError("");
    setPasswordError("");
    setErrorMessage("");

    if (username.trim() === "") {
      setUsernameError("Please Enter A username");
      return;
    }

    if (password.trim() === "") {
      setPasswordError("Please Enter a Password");
      return;
    }

    if (username.trim() === "" || password.trim() === "") {
      setErrorMessage("Please enter  password.");
      return;
    }

    const payload = {
      email: username,
      password: password,
    };

    try {
      const res = await apiCallNew("post", payload, ApiEndPoints.Login);
      if (res.status === 200) {
        setUserData(res.data);
        setToken(res.data.accesstoken);
        toast.success("Login successful!");
        setTimeout(() => {
          navigate("/");
          window.location.reload();
        }, 2000);
      } else {
        setErrorMessage(res.message);
        toast.error(res.message);
      }
    } catch (error) {
      setErrorMessage(error.response?.data?.message || "Login failed!");
      toast.error(error.response?.data?.message || "Login failed!");
    }
  };

  useEffect(() => {
    if (user) {
      axios
        .get(
          `https://www.googleapis.com/oauth2/v1/userinfo?access_token=${user.access_token}`,
          {
            headers: {
              Authorization: `Bearer ${user.access_token}`,
              Accept: "application/json",
            },
          }
        )
        .then((res) => {
          setProfile(res.data);
        })
        .catch((err) => console.log(err));
    }
  }, [user]);

  const login = useGoogleLogin({
    onSuccess: (response) => {
      setUser(response);
      handleSuccess(response);
    },
    onError: (error) => {
      handleError(error);
    },
  });

  const handleLogin = () => {
    login();
  };

  return (
    <Container
      fluid
      className="d-flex justify-content-center align-items-center vh-100"
    >
      <Row className="w-100">
        <Col xs={12} md={6} lg={4} className="mx-auto">
          <Form
            className="border p-4 shadow-sm rounded"
            onSubmit={handleSubmit}
          >
            <h3 className="text-center mb-4" style={{ fontWeight: "bold" }}>
              Login
            </h3>

            <Form.Group controlId="formEmail">
              <Form.Label>Email address</Form.Label>
              <Form.Control
                type="email"
                placeholder="Enter your email"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
              />
              {usernameError && <p className="error">{usernameError}</p>}
            </Form.Group>

            <Form.Group controlId="formPassword" className="mt-3">
              <Form.Label>Password</Form.Label>
              <Form.Control
                type={showPassword ? "text" : "password"}
                placeholder="Enter your password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
              {passwordError && <p className="error">{passwordError}</p>}
              <div
                onClick={togglePaswity}
                style={{
                  cursor: "pointer",
                  float: "right",
                  marginRight: "10px",
                  marginTop: "-32px",
                }}
              >
                {showPassword ? <FaEye /> : <FaEyeSlash />}
              </div>
            </Form.Group>

            {errorMessage && (
              <Form.Text className="text-danger">{errorMessage}</Form.Text>
            )}

            <Form.Group
              controlId="formRemember"
              className="mt-3 d-flex justify-content-between align-items-center"
            >
              <Form.Check type="checkbox" label=" Remember Me" />
              <Link to="/ForgetPassword" style={{ textDecoration: "none" }}>
                <a
                  href="/ForgetPassword"
                  style={{ color: "#44bd79", textDecoration: "none" }}
                >
                  Forgot Password?
                </a>
              </Link>
            </Form.Group>

            <Button
              variant="primary"
              type="submit"
              className="bloginn w-100 mt-4"
              style={{ backgroundColor: "#782a8c", borderColor: "#782a8c" }}
            >
              Login
            </Button>

            <div className="text-center mt-3">
              Not registered?{" "}
              <Link to="/signup" style={{ textDecoration: "none" }}>
                <a
                  href="/signup"
                  style={{ color: "#44bd79", textDecoration: "none" }}
                >
                  Create an account
                </a>
              </Link>
            </div>

            <div className="divider mt-3">
              <hr />
              <span className="ms-2 mx-2">Or Continue with</span>
              <hr />
            </div>

            <div className="d-flex justify-content-center mt-2">
              <p
                className="gbutton text-center"
                onClick={handleLogin}
                style={{ cursor: "pointer", margin: "10px auto" }}
              >
                <FcGoogle size={30} />
              </p>
            </div>
          </Form>
          <ToastContainer />
        </Col>
      </Row>
    </Container>
  );
}

export default Login;
