import React, { useState, useEffect } from "react";
import { json, useLocation } from "react-router-dom";
import "./subscription.css";
const Examseesion = () => {
  const [sessions, setSessions] = useState([]);

  console.log(">>>>>>>", sessions);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const userData = localStorage.getItem("@userData");
  const Data = JSON.parse(userData);
  console.log("USERDATA>>>", Data.Student.id);

  const location = useLocation();
  const examid = location.state.exam_id || {};
  // const Data = location.state?.examData || {};

  const payload = {
    user_id: Data.Student.id,
  };

  console.log("Examid:", examid, "DAta:", Data);

  useEffect(() => {
    const fetchExamData = async () => {
      try {
        const token = localStorage.getItem("@userToken");

        if (!token) {
          throw new Error("No token found, please log in.");
        }

        const response = await fetch(
          `https://www.secrets4exams.com/api/qbank-prev-session/${examid}`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: token,
            },
            body: JSON.stringify(payload),
          }
        );

        console.log("Response status:", response.status);
        const data = await response.json();
        console.log("API Response Data:", data.result);
        setSessions(data.result);
        console.log(data.result);
      } catch (error) {
        console.log("Error fetching data:", error);
        setError(error.message);
        setLoading(false);
      }
    };

    fetchExamData();
  }, []);
  return (
    <div className="personalinformation">
      <div className="container-fluidee">
        <h3 className="PHARMACYHEANDIN">IFOM EXAM FOR PHARMACY</h3>
      </div>
      <div className="quizbox">
        <img
          src="https://www.secrets4exams.com/frontend/images/icons_267729.png"
          alt="Exam Icon"
          className="exam-icon"
        />
        <button className="">Start</button>
      </div>
      <h1 className="text-center">Previous Sessions</h1>

      {loading ? (
        <p>Loading...</p>
      ) : error ? (
        <p>Error: {error}</p>
      ) : (
        <div className="sessions-grid">
          {sessions?.test_order?.map((session) => (
            <div className="session-card" key={session.id}>
              <h4>{session.updated_at}</h4>
              <p>Session started at {session.percent}</p>
              <p>Number of questions: {session.numberOfQuestions}</p>
              <p>Correct Answers: {session.correct}</p>
              <div
                className={`progress-bar ${
                  session.correctAnswers / session.numberOfQuestions === 1
                    ? "green"
                    : session.correctAnswers / session.numberOfQuestions >= 0.5
                    ? "yellow"
                    : "red"
                }`}
              ></div>
              <span>
                {(
                  (session.correctAnswers / session.numberOfQuestions) *
                  100
                ).toFixed(0)}
                % Correct
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Examseesion;
