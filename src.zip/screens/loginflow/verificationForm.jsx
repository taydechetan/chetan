import React, { useState } from "react";
import "./VerificationForm.css";
import { Link, useNavigate } from "react-router-dom";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import ApiEndPoints from "../../networkcall/Apiendpoint";
import { apiCallNew } from "../../networkcall/apiservises";

const VerificationForm = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState("c*****@gmail.com");
  const [code, setCode] = useState("");
  const [otp, setOtp] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    console.log("Code submitted:", code);
    const payload = {
      remember_token: otp,
      email: email,
    };

    try {
      const res = await apiCallNew("post", payload, ApiEndPoints.VerifyOtp);
      if (res.status === 200) {
        toast.success(
          "Code verified successfully. You can now reset your password!"
        );
        navigate("/");
      } else {
        toast.error(res.message);
      }
    } catch (error) {
      toast.error(
        "Verification failed. Please check the code or email and try again."
      );
    }
  };

  const handleResendCode = async () => {
    console.log("Resend code");

    const payload = {
      remember_token: otp,
      email: email,
    };

    try {
      const res = await apiCallNew("post", payload, ApiEndPoints.VerifyOtp);
      if (res.status === 200) {
        toast.success(
          "Code verified successfully. You can now reset your password!"
        );
        navigate("/");
      } else {
        toast.error(res.message);
      }
    } catch (error) {
      toast.error(
        "Verification failed. Please check the code or email and try again."
      );
    }
  };

  return (
    <div className="verification-container">
      <form onSubmit={handleSubmit} className="verification-form">
        <h2>Enter the 6-digit code</h2>
        <p>
          Check <span>{email}</span> for a verification code.
          <Link to="/ForgetPassword">
            <a className="change-link">Change</a>
          </Link>
        </p>
        <div className="input-container">
          <input
            type="text"
            className="code-input"
            value={code}
            onChange={(e) => setCode(e.target.value)}
            placeholder="Enter code"
          />
        </div>
        <a type="button" className="resend-link" onClick={handleResendCode}>
          Resend code
        </a>
        <button type="submit" className="submit-btny mt-4">
          Submit
        </button>
        <p className="note mt-4">
          If you don’t see the email in your inbox, check your spam folder.
          <br />
          If it’s not there, the email address may not be confirmed, or it may
          not match an existing account.
        </p>
      </form>
    </div>
  );
};

export default VerificationForm;
