import React from "react";

export default function resetpassword() {
  return (
    <div>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Fuga similique
      quos perferendis ipsam nihil tempora eum veniam consequuntur laborum
      molestias.
    </div>
  );
}
