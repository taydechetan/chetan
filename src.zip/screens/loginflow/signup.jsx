import React, { useState, useEffect } from "react";
import { googleLogout, useGoogleLogin } from "@react-oauth/google";
import axios from "axios";
import { FcGoogle } from "react-icons/fc";
import { Link, useNavigate } from "react-router-dom";
import "./SignUp.css";
import { apiCallNew } from "../../networkcall/apiservises";
import ApiEndPoints from "../../networkcall/Apiendpoint";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { FaEye, FaEyeSlash } from "react-icons/fa";
import { setToken, setUserData } from "../../helper/storage";

function SignUp() {
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [username, setUsername] = useState("");
  const [emailname, setEmailname] = useState("");
  const [password, setPassword] = useState("");
  const [conformpass, setConformpass] = useState("");
  const [usernameError, setUsernameError] = useState("");
  const [emailError, setEmailError] = useState("");
  const [passError, setPassError] = useState("");
  const [conformError, setConformError] = useState("");
  const [phonenum, setphonenum] = useState("");
  const [phoneerror, setphoneerror] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [showPasswordd, setShowPasswordd] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");

  const navigate = useNavigate();

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  const togglePassword = () => {
    setShowPasswordd(!showPasswordd);
  };

  const login = useGoogleLogin({
    onSuccess: (response) => {
      setUser(response);
    },
    onError: (error) => console.log("Login Failed:", error),
  });

  useEffect(() => {
    if (user) {
      axios
        .get(
          `https://www.googleapis.com/oauth2/v1/userinfo?access_token=${user.access_token}`,
          {
            headers: {
              Authorization: `Bearer ${user.access_token}`,
              Accept: "application/json",
            },
          }
        )
        .then((res) => {
          setProfile(res.data);
        })
        .catch((err) => console.log(err));
    }
  }, [user]);

  const handleLogin = () => {
    login();
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    let isValid = true;

    if (username.trim() === "") {
      setUsernameError("Please enter your Name.");
      isValid = false;
    } else {
      setUsernameError("");
    }

    if (emailname.trim() === "") {
      setEmailError("Please enter your Email.");
      isValid = false;
    } else {
      setEmailError("");
    }

    if (password.trim() === "") {
      setPassError("Please enter your Password.");
      isValid = false;
    } else if (password.length < 8) {
      setPassError("Password must be at least 8 characters long.");
      isValid = false;
    } else if (password.includes(" ")) {
      setPassError("Password cannot add contain spaces.");
      isValid = false;
    } else if (!/[a-z]/.test(password)) {
      setPassError("Password must contain at least one lowercase letter.");
      isValid = false;
    } else if (!/[A-Z]/.test(password)) {
      setPassError("Password must contain at least one uppercase letter.");
      isValid = false;
    } else if (!/\d/.test(password)) {
      setPassError("Password must contain at least one number.");
      isValid = false;
    } else if (!/[!@#$%^&*(),.?":{}|<>]/.test(password)) {
      setPassError("Password must contain at least one special character.");
      isValid = false;
    } else {
      setPassError("");
    }

    if (conformpass.trim() === "") {
      setConformError("Please confirm your Password.");
      isValid = false;
    } else if (conformpass !== password) {
      setConformError("Passwords do not match.");
      isValid = false;
    } else {
      setConformError("");
    }

    if (phonenum.trim() === "") {
      setphoneerror("Please enter your phone number.");
      isValid = false;
    } else if (phonenum.length !== 10) {
      setphoneerror("Phone number must be exactly 10 digits long.");
      isValid = false;
    } else if (!/^[6-9]\d{9}$/.test(phonenum)) {
      setphoneerror(
        "Please enter a valid phone number. Should start with 6-9 and be 10 digits long."
      );
      isValid = false;
    } else if (/(\d)\1{9}/.test(phonenum)) {
      setphoneerror("Phone number cannot have all identical digits.");
      isValid = false;
    } else if (phonenum === "1234567890" || phonenum === "9876543210") {
      setphoneerror(
        "Phone number cannot be a generic sequence like '1234567890' or '9876543210'."
      );
      isValid = false;
    } else {
      setphoneerror("");
    }

    if (isValid) {
      const payload = {
        name: username,
        email: emailname,
        password: password,
        confirmPassword: conformpass,
        mobile: phonenum,
        role: "s",
      };

      // try {
      //   const res = await apiCallNew("post", payload, ApiEndPoints.Register);
      //   if (res.status === 200) {
      //     setUserData(res.data);
      //     setToken(res.data.accesstoken);
      //     toast.success("Login successful!");
      //     setTimeout(() => {
      //       navigate("/");
      //       window.location.reload();
      //     }, 2000);
      //   } else {
      //     setErrorMessage(res.message);
      //     toast.error(res.message);
      //   }
      // } catch (error) {
      //   setErrorMessage(error.response?.data?.message || "Login failed!");
      //   toast.error(error.response?.data?.message || "Login failed!");
      // }

      try {
        const res = await apiCallNew("post", payload, ApiEndPoints.Register);
        console.log(res);
        if (res.status === 200) {
          toast.success("Registration successful!");
          setTimeout(() => {
            navigate("/");
          }, 3000);
        } else {
          toast.error(res.errors[0].msg);
        }
      } catch (error) {
        console.log(error);
        toast.error(error[0]?.msg);
      }
    }
  };

  return (
    <div className="sign-up-container">
      <ToastContainer />
      <h2 className="sign-up-title">Register</h2>
      <form className="sign-up-form" onSubmit={handleSubmit}>
        <label className="form-group">
          <p>Name</p>
          <input
            type="text"
            placeholder="Enter a name"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />
          {usernameError && <p className="error">{usernameError}</p>}
        </label>

        <label className="form-group">
          <p>Email address</p>
          <input
            type="email"
            placeholder="eg: foo@bar.com"
            value={emailname}
            onChange={(e) => setEmailname(e.target.value)}
          />
          {emailError && <p className="error">{emailError}</p>}
        </label>

        <label
          className="form-group"
          style={{ position: "relative", width: "100%", minHeight: "80px" }}
        >
          <p>Enter a password</p>
          <input
            type={showPasswordd ? "text" : "password"}
            placeholder="Enter a password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            style={{
              paddingRight: "30px",
              width: "100%",
              boxSizing: "border-box",
            }}
          />
          <div
            style={{
              position: "absolute",
              right: "10px",
              top: "35px",
              cursor: "pointer",
            }}
            onClick={togglePassword}
          >
            {showPasswordd ? <FaEye /> : <FaEyeSlash />}
          </div>
          {passError && (
            <p
              className="error"
              style={{
                color: "red",
                marginTop: "5px",
              }}
            >
              {passError}
            </p>
          )}
        </label>

        <label
          className="form-group"
          style={{ position: "relative", width: "100%", minHeight: "80px" }}
        >
          <p>Confirm password</p>
          <input
            type={showPassword ? "text" : "password"}
            placeholder="Confirm password"
            value={conformpass}
            onChange={(e) => setConformpass(e.target.value)}
            style={{
              paddingRight: "30px",
              width: "100%",
              boxSizing: "border-box",
            }}
          />
          <div
            style={{
              position: "absolute",
              right: "10px",
              top: "35px",
              cursor: "pointer",
            }}
            onClick={togglePasswordVisibility}
          >
            {showPassword ? <FaEye /> : <FaEyeSlash />}
          </div>
          {conformError && (
            <p
              className="error"
              style={{
                color: "red",
                marginTop: "5px",
              }}
            >
              {conformError}
            </p>
          )}
        </label>

        <label className="form-group">
          <p>Phone Number</p>
          <input
            type="number"
            placeholder="Phone Number"
            value={phonenum}
            onChange={(e) => {
              const value = e.target.value;
              if (/^\d{0,10}$/.test(value)) {
                setphonenum(value);
                setphoneerror("");
              } else {
                setphoneerror("Phone number must be exactly 10 digits long.");
              }
            }}
          />
          {phoneerror && <p className="error">{phoneerror}</p>}
        </label>

        <div className="form-actions">
          <button type="submit" className="submit-button">
            Create Account
          </button>
          <Link to="/Login" className="login-link">
            Already have an account?
          </Link>
        </div>

        <div className="divider">
          <hr />
          <span className="divider-text">Or Continue with</span>
          <hr />
        </div>

        <p
          className="gbutton text-center m-10px auto"
          onClick={handleLogin}
          style={{ margin: "10px auto" }}
        >
          <FcGoogle />
        </p>
      </form>
    </div>
  );
}

export default SignUp;
