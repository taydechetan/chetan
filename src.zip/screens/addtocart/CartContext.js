// import React, { createContext, useContext, useState, useEffect } from 'react';
// import ApiEndPoints from '../../networkcall/Apiendpoint';

// const CartContext = createContext();

// export const useCart = () => useContext(CartContext);

// export const CartProvider = ({ children }) => {
//     const [cart, setCart] = useState(() => {
//         const savedCart = localStorage.getItem('cart');
//         return savedCart ? JSON.parse(savedCart) : [];
//     });
//     const data = localStorage.getItem("@userData");
//     const user = JSON.parse(data);
//     const [cartdata, setCartdata] = useState([])

//     useEffect(() => {
//         localStorage.setItem('cart', JSON.stringify(cart));
//     }, [cart]);

//     const addToCart = (item) => {
//         setCart((prev) => [...prev, item]);
//     };

//     const removeItem = (itemId) => {
//         setCart((prevCart) => prevCart.filter((item) => item.id !== itemId));
//     };

//     const loginUser = (token) => {
//         localStorage.setItem('@userToken', token);
//     };

//     const clearCart = () => {
//         setCart([]);
//     };

//     const updateQuantity = (itemId, newQuantity) => {
//         setCart((prevCart) =>
//             prevCart.map(item =>
//                 item.id === itemId ? { ...item, quantity: Number(newQuantity) } : item
//             )
//         );
//     };

//     const getCartList = async () => {
//         try {
//             const token = localStorage.getItem("@userToken");
//             const response = await fetch(`${ApiEndPoints.CartList}${user.Student.id}`, {
//                 method: "GET",
//                 headers: {
//                     "Content-Type": "application/json",
//                     Authorization: token,
//                 },
//             });

//             if (response.ok) {
//                 const data = await response.json();
//                 setCartdata(data.data.length);
//             } else {
//                 console.log("Failed to fetch data: ", response.status);
//             }
//         } catch (error) {
//             console.error("Error fetching categories:", error);
//         }
//     };
//     return (
//         <CartContext.Provider value={{ cart, addToCart, clearCart, updateQuantity, removeItem, loginUser, getCartList, cartdata }}>
//             {children}
//         </CartContext.Provider>
//     );
// };


import React, { createContext, useContext, useState, useEffect } from 'react';
import ApiEndPoints from '../../networkcall/Apiendpoint';

const CartContext = createContext();

export const useCart = () => useContext(CartContext);

export const CartProvider = ({ children }) => {
    // Initialize cart from localStorage, safely handling empty or invalid JSON
    const [cart, setCart] = useState(() => {
        const savedCart = localStorage.getItem('cart');
        return savedCart ? JSON.parse(savedCart) : [];
    });

    // Safely retrieve user data from localStorage
    const data = localStorage.getItem("@userData");
    let user = null;
    try {
        user = data ? JSON.parse(data) : null; // Avoid parsing if data is null or undefined
    } catch (error) {
        console.error("Error parsing user data from localStorage:", error);
    }

    const [cartdata, setCartdata] = useState([]);

    useEffect(() => {
        localStorage.setItem('cart', JSON.stringify(cart));
    }, [cart]);

    const addToCart = (item) => {
        setCart((prev) => [...prev, item]);
    };

    const removeItem = (itemId) => {
        setCart((prevCart) => prevCart.filter((item) => item.id !== itemId));
    };

    const loginUser = (token) => {
        localStorage.setItem('@userToken', token);
    };

    const clearCart = () => {
        setCart([]);
    };

    const updateQuantity = (itemId, newQuantity) => {
        setCart((prevCart) =>
            prevCart.map(item =>
                item.id === itemId ? { ...item, quantity: Number(newQuantity) } : item
            )
        );
    };

    const getCartList = async () => {
        try {
            const token = localStorage.getItem("@userToken");
            if (!token || !user) {
                console.error("User or token not found");
                return;
            }

            const response = await fetch(`${ApiEndPoints.CartList}${user.Student.id}`, {
                method: "GET",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: token,
                },
            });

            if (response.ok) {
                const data = await response.json();
                setCartdata(data.data.length);
            } else {
                console.log("Failed to fetch data: ", response.status);
            }
        } catch (error) {
            console.error("Error fetching cart list:", error);
        }
    };

    return (
        <CartContext.Provider value={{ cart, addToCart, clearCart, updateQuantity, removeItem, loginUser, getCartList, cartdata }}>
            {children}
        </CartContext.Provider>
    );
};


