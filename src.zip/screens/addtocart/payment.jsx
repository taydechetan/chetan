import React, { useState, useEffect } from "react";
import { PayPalButtons, PayPalScriptProvider } from "@paypal/react-paypal-js";
import "./payment.css";
import ApiEndPoints from "../../networkcall/Apiendpoint";
import { apiCallNew } from "../../networkcall/apiservises";

const Payment = () => {
  const [paymentMethod, setPaymentMethod] = useState("");
  const [showPayPal, setShowPayPal] = useState(false);
  const [totalPrice, setTotalPrice] = useState(0);
  const data = localStorage.getItem("@userData");
  const user = JSON.parse(data);
  const [packageData, setPackageData] = useState([]);
  const [Pdata, Psetdata] = useState([]);

  useEffect(() => {
    const queryParams = new URLSearchParams(window.location.search);
    const total = queryParams.get("total");
    getPackagelistt();
    if (total) {
      setTotalPrice(total);
    }
  }, []);

  useEffect(() => {
    if (user?.Student?.id) {
      getPackageList(user.Student.id);
    }
  }, [user?.Student?.id]);

  const handlePaymentChange = (event) => {
    setPaymentMethod(event.target.value);
    setShowPayPal(event.target.value === "paypal");
  };

  const getPackageList = async (id) => {
    try {
      const token = localStorage.getItem("@userToken");
      const response = await fetch(`${ApiEndPoints.CartList}${id}`, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          Authorization: token,
        },
      });

      if (response.ok) {
        const data = await response.json();
        setPackageData(data?.data || []);
      } else {
        console.log("Failed to fetch data: ", response.status);
      }
    } catch (error) {
      console.error("Error fetching package list:", error);
    }
  };

  const getPackagelistt = async (id) => {
    try {
      const response = await apiCallNew("get", null, ApiEndPoints.OrderPayment);
      if (response.code === 200) {
        Psetdata(response.result);
      } else {
        console.log("Failed to fetch data: ", response.status);
      }
    } catch (error) {
      console.error("Error fetching categories:", error);
    }
  };

  const Removecart = async (id) => {
    try {
      const token = localStorage.getItem("@userToken");
      const response = await fetch(`${ApiEndPoints.RemoveCart}${id}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: token,
        },
      });

      if (response.ok) {
        const data = await response.json();
        getPackageList(user?.Student?.id);
      } else {
        console.log("Failed to fetch data: ", response.status);
      }
    } catch (error) {
      console.error("Error removing item:", error);
    }
  };

  const initialOptions = {
    clientId:
      "AciHbOHAJ3-W-X11euydkqLUozOvRB_4vby1wfabm-zXn8q5ErzFw4YVN0UKQ2UCO4Ri9-95ZND4eouM",
    currency: "USD",
    intent: "capture",
  };

  const totalPrise = packageData.reduce((total, item) => {
    const price = parseFloat(item.price) || 0;
    return total + price;
  }, 0);

  return (
    <div className="container">
      <div className="cart-container">
        {packageData.length === 0 ? (
          <p>No items in your cart.</p>
        ) : (
          <div className="cart-itemse">
            {packageData.map((item) => (
              <div key={item.id} className="cart-itemm">
                <h4 className="cart-item-title">{item.package?.title}</h4>
                <div className="cart-item-row">
                  <span className="cart-item-label">Amount:</span>
                  <span className="cart-item-price">${item.price}</span>
                </div>
                <div>
                  <a
                    onClick={() => Removecart(item.id)}
                    className="cart-item-remove"
                  >
                    Remove Item
                  </a>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="confirm-pay">
        <h3>Confirm & Pay</h3>
        <div className="order-summary mt-5">
          <p className="d-flex justify-content-between align-items-center">
            <strong>Order total</strong>
            <span>${totalPrise}</span>
          </p>
        </div>

        <h4>Payment method</h4>

        <div className="payment-method d-flex justify-content-between align-items-center border">
          <div className="d-flex align-items-center w-100">
            <label
              className="d-flex align-items-center w-100 justify-content-between"
              style={{ padding: "9px 5px" }}
            >
              <div className="d-flex align-items-center">
                <input
                  type="radio"
                  value="paypal"
                  checked={paymentMethod === "paypal"}
                  onChange={handlePaymentChange}
                  className="me-2"
                />
                <span>Paypal</span>
              </div>
              <img
                src="https://www.secrets4exams.com/images/paypal_icon.svg"
                alt="Paypal"
                className="payment-img"
                style={{ width: "20%" }}
              />
            </label>
          </div>
        </div>

        {showPayPal && (
          <div className="paypal-container mt-3">
            <PayPalScriptProvider options={initialOptions}>
              <PayPalButtons
                createOrder={(data, actions) => {
                  return actions.order.create({
                    purchase_units: [
                      {
                        amount: {
                          value: totalPrise,
                        },
                      },
                    ],
                  });
                }}
                onApprove={async (data, actions) => {
                  const details = await actions.order.capture();
                  console.log(
                    "Transaction completed by " + details.payer.name.given_name
                  );
                  alert(
                    "Transaction completed by " + details.payer.name.given_name
                  );
                }}
                onError={(err) => {
                  console.error("PayPal Checkout onError", err);
                }}
              />
            </PayPalScriptProvider>
          </div>
        )}

        <button className="proceed-button mt-3">Proceed</button>
      </div>
    </div>
  );
};

export default Payment;
