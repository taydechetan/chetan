import React, { useEffect, useState } from "react";
import { useCart } from "./CartContext";
import { FaXmark } from "react-icons/fa6";
import "./cart.css";
import { Link, useParams } from "react-router-dom";
import ApiEndPoints from "../../networkcall/Apiendpoint";
import { apiCallNew } from "../../networkcall/apiservises";
import { toast } from "react-toastify";

const Cart = () => {
  const {  updateQuantity, getCartList } = useCart();
  const data = localStorage.getItem("@userData");
  const user = JSON.parse(data);
  const [packageData, setPackagedataa] = useState([]);

  console.log("packageData", packageData);
  useEffect(() => {
    getPackageList(user?.Student?.id);
  }, []);
  

  
  //  await getUserdata()
  //   .then((user) => {
  //     setUserdata(user.Student);
  //     console.log("usrrr", user.Student);
  //   })
  //   .catch((error) => {
  //     console.error("Error fetching user data:", error);
  //   });

  // const getPackageList = async (id) => {
  //   try {
  //     const response = await apiCallNew(
  //       "get",
  //       null,
  //       ApiEndPoints.CartList + id
  //     );
  //     if (response.code === 200) {
  //       setPackagedataa(response.data);
  //     } else {
  //       console.log("Failed to fetch data: ", response.status);
  //     }
  //   } catch (error) {
  //     console.error("Error fetching categories:", error);
  //   }
  // };

  const getPackageList = async (id) => {
    try {
      const token = localStorage.getItem("@userToken");
      const response = await fetch(`${ApiEndPoints.CartList}${id}`, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          Authorization: token,
        },
      });

      if (response.ok) {
        const data = await response.json();
        setPackagedataa(data);
        getCartList()
      } else {
        console.log("Failed to fetch data: ", response.status);
      }
    } catch (error) {
      console.error("Error fetching categories:", error);
    }
  };

  const Removecart = async (id) => {
    try {
      const token = localStorage.getItem("@userToken");
      const response = await fetch(`${ApiEndPoints.RemoveCart}${id}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: token,
        },
      });

      if (response.ok) {
        const data = await response.json();
        getPackageList(user?.Student?.id);
      } else {
        console.log("Failed to fetch data: ", response.status);
      }
    } catch (error) {
      console.error("Error fetching categories:", error);
    }
  };

  return (
    <div className="cart-page mt-5 mb-5">
      <div className="cart-header d-flex">
        <span
          className="iconns"
          style={{ padding: "1px 8px", fontSize: " 1.3rem" }}
        >
          👜
        </span>
        <h2>Your Items</h2>
      </div>

      {packageData?.data?.length > 0 ? (
        <div className="cart-items">
          {packageData?.data?.map((item) => (
            <div className="cart-item" key={item.id}>
              <div className="item-details">
                <p className="item-title fw-bold">{item?.package?.title}</p>{" "}
                <p
                  className="item-quantity fw-bold"
                  style={{ fontSize: "15px" }}
                >
                  Quantity:
                  <input
                    type="text"
                    value={item.quantity}
                    min="1"
                    className="quantity-input"
                    onChange={(e) => updateQuantity(item.id, e.target.value)}
                  />
                </p>
              </div>
              <div className="item-price">
                ${item.price ? (item.price * item.quantity).toFixed(2) : "0.00"}{" "}
              </div>
              <button
                className="remove-item"
                onClick={() => Removecart(item.id)}
              >
                <FaXmark />
              </button>
            </div>
          ))}

          <div className="cart-total">
            <h5>{Cart.title} </h5>
          </div>
          <Link to="/payment" style={{ textDecoration: "none" }}>
            <div className="cart-actions">
              <button className="continue-btn">Continue</button>
            </div>
          </Link>
        </div>
      ) : (
        <div className="empty-cart">
          <img
            src="https://www.secrets4exams.com/frontend/images/empty-cart.png"
            alt="Empty Cart"
            className="empty-cart-image"
          />
          <p>Your cart is empty.</p>
          <Link to="/">
            <button className="continue-btn" style={{ textDecoration: "none" }}>
              Continue
            </button>
          </Link>
        </div>
      )}
    </div>
  );
};

export default Cart;
