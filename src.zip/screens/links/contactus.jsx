import React, { useEffect, useState } from "react";
import "./Contactus.css";
import { Container, Row, Col, Form, Button } from "react-bootstrap";
import { CiLocationOn } from "react-icons/ci";
import { SiWhatsapp } from "react-icons/si";
import { AiTwotoneMail } from "react-icons/ai";
import ReCAPTCHA from "react-google-recaptcha";
import Profile from "../home/Profile";
import ApiEndPoints from "../../networkcall/Apiendpoint";
import { apiCallNew } from "../../networkcall/apiservises";
import { useParams } from "react-router-dom";

const inputStyle = {
  border: "none",
  borderRadius: "0",
  margin: "10px 0 20px 20px",
  background: "#ececec",
  padding: "20px",
  height: "50px",
  width: "calc(100% - 40px)",
  fontSize: "20px",
};

const iconStyle = {
  padding: "10px",
  backgroundColor: "#782a8c",
  borderRadius: "50%",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  marginRight: "10px",
  color: "#fff",
};

const textareaStyle = {
  ...inputStyle,
  height: "100px",
  marginBottom: "30px",
};

const onChange = () => {};

const Contact = () => {
  const { id } = useParams();
  const [constdata, setconstdata] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    window.scrollTo(0, 0);
    contacuss(id);
  }, [id]);

  const contacuss = async () => {
    try {
      const response = await apiCallNew("get", null, ApiEndPoints.Contactus);
      if (response.status === 200) {
        setconstdata(response.data);
        // console.log("Response data:", response.data);
      } else {
        setError(`Failed to fetch carousel data: ${response.statusText}`);
      }
    } catch (error) {
      setError(`Failed to fetch carousel data: ${error.message}`);
    }
  };

  return (
    <>
      <div>
        <div className="Contactpage">
          <div className="contACTimagesection">
            <div className="blackbackCONTACT"></div>
            <div className="text-contentt">
              <p
                style={{
                  backgroundColor: "rgba(255, 255, 255, .09)",
                  padding: "10px 12px",
                  borderradius: "5px",
                }}
              >
                Home / Contactus
              </p>
              <h1>CONTACTUS</h1>
            </div>
          </div>
        </div>
        <Container
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <Row className="my-4">
            {" "}
            <Col md={4}>
              <h5>Get in touch with us</h5>
              <h1>Ask for your query</h1>
              <div className="contact-info">
                <div className="d-flex align-items-center mb-3">
                  <div>
                    <p style={iconStyle}>
                      <CiLocationOn />
                    </p>
                  </div>
                  <div className="d-flex flex-column">
                    <h6>Address</h6>
                    <span>UAE</span>
                  </div>
                </div>

                <div className="d-flex align-items-center mb-3">
                  <div style={iconStyle}>
                    <SiWhatsapp />
                  </div>
                  <div>
                    <a>Call Anytime:</a>
                  </div>
                </div>

                <div className="d-flex align-items-center mb-3">
                  <div style={iconStyle}>
                    <AiTwotoneMail />
                  </div>
                  <div className="d-flex flex-column">
                    <h6>Email</h6>
                    <span>info@secrets4exams.com</span>{" "}
                  </div>
                </div>
              </div>
            </Col>
            <Col md={8}>
              <h4>Contact us</h4>
              <Form className="border">
                <Row>
                  <Col md={6}>
                    <Form.Group className="mb-3">
                      <Form.Control
                        type="text"
                        placeholder="Name"
                        style={inputStyle}
                      />
                    </Form.Group>
                  </Col>
                  <Col md={6}>
                    <Form.Group className="mb-3">
                      <Form.Control
                        type="email"
                        placeholder="name@example.com"
                        style={inputStyle}
                      />
                    </Form.Group>
                  </Col>
                </Row>
                <Row>
                  <Col md={6}>
                    <Form.Group className="mb-3">
                      <Form.Control
                        type="number"
                        placeholder="Phone No."
                        style={inputStyle}
                      />
                    </Form.Group>
                  </Col>
                  <Col md={6}>
                    <Form.Group className="mb-3">
                      <Form.Control
                        type="text"
                        placeholder="Subject"
                        style={inputStyle}
                      />
                    </Form.Group>
                  </Col>
                </Row>
                <Form.Group className="mb-3">
                  <Form.Control
                    as="textarea"
                    rows={3}
                    placeholder="Message"
                    style={textareaStyle}
                  />
                </Form.Group>

                <div className="ms-3">
                  <ReCAPTCHA
                    sitekey="6LdeI2UqAAAAACKrc3-_WggfiDu8WHMyUuuK8kos"
                    onChange={onChange}
                  />
                </div>

                <button type="submit" className="btncont ms-3 mb-3 mt-2">
                  Submit
                </button>
              </Form>
            </Col>
          </Row>
        </Container>
      </div>

      <Profile />
    </>
  );
};

export default Contact;
