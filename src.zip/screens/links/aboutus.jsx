import React, { useEffect, useState } from "react";
import "./Aboutus.css";
import { Link } from "react-router-dom";
import { apiCallNew } from "../../networkcall/apiservises";
import ApiEndPoints from "../../networkcall/Apiendpoint";

const About = () => {
  const [aboutData, setAboutData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchAboutData = async () => {
      try {
        const response = await apiCallNew("get", null, ApiEndPoints.Aboutus);
        if (response.status === 200) {
          const aboutInfo = response.data.find(
            (item) => item.slug === "about-us"
          );
          setAboutData(aboutInfo);
        } else {
          throw new Error("Failed to fetch about data");
        }
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchAboutData();
  }, []);

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>Error: {error}</div>;
  }

  if (!aboutData) {
    return <div>No about data available.</div>;
  }

  const parser = new DOMParser();
  const htmlDoc = parser.parseFromString(aboutData.long_desc, "text/html");
  const heading = htmlDoc.querySelector("h3");
  const paragraph = htmlDoc.querySelector("p");

  return (
    <div className="AboutContainer">
      <div className="AboutImageSection">
        <div className="BlackOverlay"></div>
        <div className="TextContent ms-3">
          <h6 className="Breadcrumb">Home / About Us</h6>
          <h1>ABOUT US</h1>
        </div>
      </div>

      <div className="row mt-4">
        <div
          className="about-text-section col-md-6"
          style={{
            display: "flex",
            flexDirection: "column",
            margin: "20px auto",
          }}
        >
          <link
            rel="stylesheet"
            href="https://fonts.googleapis.com/css?family=Sofia&effect=neon|outline|emboss|shadow-multiple"
          />
          <h1 className="font-effect-outline ms-3">{aboutData.name}</h1>
          {heading && (
            <h1 className="about-subtitle ms-3 fw-bold">{heading.innerHTML}</h1>
          )}
          {paragraph && (
            <p className="about-description ms-3">{paragraph.innerHTML}</p>
          )}
        </div>

        <div className="about-image-section col-md-6 mb-4">
          <img
            src={`https://www.secrets4exams.com/images/pages/${aboutData.image}`}
            alt="About us"
            className="AboutImage"
          />
        </div>
      </div>
    </div>
  );
};

export default About;
