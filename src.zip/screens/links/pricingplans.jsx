import React, { useEffect, useState } from "react";
import "./pricingplans.css";
import { useCart } from "../addtocart/CartContext";
import { FaCheck } from "react-icons/fa6";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { apiCallNew } from "../../networkcall/apiservises";
import ApiEndPoints from "../../networkcall/Apiendpoint";
import { useParams, useNavigate } from "react-router-dom";

const PricingPlans = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { cart, addToCart, getCartList } = useCart();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [packageData, setPackagedata] = useState([]);

  useEffect(() => {
    getPackageList(id);
  }, [id]);

  const getPackageList = async (id) => {
    try {
      const response = await apiCallNew(
        "get",
        null,
        ApiEndPoints.PackageList + id
      );
      if (response.code === 200) {
        setPackagedata(response.result);
      } else {
        console.log("Failed to fetch data: ", response.status);
      }
    } catch (error) {
      console.error("Error fetching categories:", error);
    }
  };

  const addtocart = async (item) => {
    const token = window.localStorage.getItem("@userToken");

    if (!token) {
      toast.error("Please log in to purchase this plan.");
      navigate("/login");
      return;
    }

    const payload = {
      exam_id: id,
      quantity: "1",
      package_id: item?.id,
      package_name: item?.duration.duration_name,
      price: item?.amount,
    };

    try {
      const response = await fetch(ApiEndPoints.AddtoCart, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `${token}`,
        },
        body: JSON.stringify(payload),
      });
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const result = await response.json();
      toast.success(`${item.duration.duration_name} plan added to cart!`);
      getCartList();
    } catch (error) {
      console.error("Already added to package");
      toast.error("Already added to package");
    }
  };

  const toggleModal = () => {
    setIsModalOpen(!isModalOpen);
  };

  return (
    <div className="container pricing-plans">
      <ToastContainer />

      {packageData?.map((plan, index) => (
        <div className="plan" key={index}>
          <h3>{plan.duration.duration_name}</h3>
          <p className="price">{plan.amount}$</p>
          <button className="buy-button" onClick={() => addtocart(plan)}>
            Buy
          </button>
          <div className="features">
            <p>
              <strong>Included Features:</strong>
            </p>
            <hr />
            <ul>
              {plan.exam_list.map((feature, idx) => (
                <li key={idx}>
                  <FaCheck /> {feature.title}
                </li>
              ))}
            </ul>
          </div>
        </div>
      ))}
    </div>
  );
};

export default PricingPlans;
