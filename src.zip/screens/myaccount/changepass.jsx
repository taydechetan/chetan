import React, { useState, useEffect } from "react";
import "./changepass.css";
import { IoPerson } from "react-icons/io5";
import { MdArrowForwardIos } from "react-icons/md";
import { Link } from "react-router-dom";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import ApiEndPoints from "../../networkcall/Apiendpoint";
import { apiCallNew } from "../../networkcall/apiservises";
import { setToken, setUserData } from "../../helper/storage";

const Changepass = () => {
  const [currentPassword, setCurrentPassword] = useState("");
  const [currenpasseror, setcurrenpasseror] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [newpasserror, setnewpasserror] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [confirmpasserror, setconfirmpasserror] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  const [carousal, setcarousal] = useState([]);
  const [error, setError] = useState("");

  useEffect(
    (id) => {
      cahngepasword(id);
      setErrorMessage("");
    },
    [currentPassword, newPassword, confirmPassword]
  );

  const cahngepasword = async () => {
    try {
      const response = await apiCallNew("Put", null, ApiEndPoints.Changepass);
      if (response.status == 200) {
        setcarousal(response.data);
        console.log("Fetched carousal data:", response.data);
      } else {
        setError("Failed to fetch carousal data: " + response.statusText);
      }
    } catch (error) {
      setError("Failed to fetch carousal data: " + error.message);
    }
  };

  const handleUpdate = async (e) => {
    e.preventDefault();

    if (newPassword !== confirmPassword) {
      setErrorMessage("New password and confirm password do not match");
      return;
    }

    if (!currentPassword.trim()) {
      setcurrenpasseror("Please enter your current password");
      return;
    }

    if (!newPassword.trim()) {
      setnewpasserror("Please enter your new password");
      return;
    }

    if (!confirmPassword.trim()) {
      setconfirmpasserror("Please enter your confirm password");
      return;
    }

    setErrorMessage("");
    setSuccessMessage("");

    const payload = {
      currentPassword: currentPassword.trim(),
      newPassword: newPassword.trim(),
      confirmPassword: confirmPassword.trim(),
    };

    console.log("Payload to be sent:", payload);

    try {
      const res = await apiCallNew("post", payload, ApiEndPoints.Changepass);

      if (res.status === 200) {
        console.log("response", res);
        setUserData(res.data);
        setToken(res.data.accesstoken);
        toast.success("Password changed successfully!");
        setSuccessMessage("Password updated successfully.");
        handleCancel();
      } else {
        toast.error("Password update failed. Please check your credentials.");
        setErrorMessage(res.message || "Password update failed.");
      }
    } catch (error) {
      console.error(error);
      toast.error("An error occurred. Please try again.");
      setErrorMessage(error.message || "An unexpected error occurred.");
    }
  };

  const handleCancel = () => {
    setCurrentPassword("");
    setNewPassword("");
    setConfirmPassword("");
    setErrorMessage("");
    setSuccessMessage("");
    setconfirmpasserror("");
    setnewpasserror("");
    setcurrenpasseror("");
  };

  return (
    <div className="personalinformation">
      <div className="container-fluid">
        <h3 className="henadinpersonala">Home/profile</h3>
      </div>
      <div className="row m-0 p-0">
        <div className="col-12 col-md-4">
          <div className="sidebar-container">
            <div className="account-section m-1 d-flex ms-4">
              <span
                className="account-icon text-primary"
                style={{ padding: "4px 10px", fontSize: "16px" }}
              >
                <IoPerson style={{ color: "#782a8c" }} />
              </span>
              <h3 className="text-secondary ">My Account</h3>
            </div>
            <ul className="menu-list">
              <Link to="/Personalinfo" style={{ textDecoration: "none" }}>
                <li
                  className="menu-item active d-flex"
                  style={{
                    padding: "10px 12px",
                    alignItems: "center",
                    justifyContent: "space-between",
                  }}
                >
                  Personal Information
                  <span className="arrow">
                    <MdArrowForwardIos />
                  </span>
                </li>
              </Link>

              <Link
                to="/Startstuding"
                style={{ textDecoration: "none", color: "inherit" }}
              >
                <li
                  className="menu-item d-flex"
                  style={{
                    padding: "10px 12px",
                    alignItems: "center",
                    justifyContent: "space-between",
                  }}
                >
                  My Package List
                  <span className="arrow">
                    <MdArrowForwardIos />
                  </span>
                </li>
              </Link>

              <Link
                to="/Changepass"
                style={{ textDecoration: "none", color: "inherit" }}
              >
                <li
                  className="menu-item d-flex"
                  style={{
                    padding: "10px 12px",
                    alignItems: "center",
                    justifyContent: "space-between",
                  }}
                >
                  Change Password
                  <span className="arrow">
                    <MdArrowForwardIos />
                  </span>
                </li>
              </Link>
            </ul>
          </div>
        </div>
        <div className="col-6">
          <div className="password-change-container">
            <h2>Password Change</h2>

            {successMessage && (
              <div className="success-message">{successMessage}</div>
            )}
            <form onSubmit={handleUpdate}>
              <div className="form-group">
                <label htmlFor="currentPassword">Current Password</label>
                <input
                  type="password"
                  id="currentPassword"
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  required
                />
              </div>
              {currenpasseror && (
                <div className="error-message" style={{ color: "red" }}>
                  {currenpasseror}
                </div>
              )}

              <div className="form-group">
                <label htmlFor="newPassword">New Password</label>
                <input
                  type="password"
                  id="newPassword"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  required
                />
              </div>
              {newpasserror && (
                <div className="error-message" style={{ color: "red" }}>
                  {newpasserror}
                </div>
              )}

              <div className="form-group">
                <label htmlFor="confirmPassword">Confirm Password</label>
                <input
                  type="password"
                  id="confirmPassword"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  required
                />
              </div>
              {confirmpasserror && (
                <div className="error-message" style={{ color: "red" }}>
                  {confirmpasserror}
                </div>
              )}
              <div className="button-group">
                <button type="submit" className="update-button mb-5 mt-4">
                  Update
                </button>

                <button
                  type="button"
                  className="cancel-bttnn ms-3"
                  onClick={handleCancel}
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Changepass;
