import React from 'react'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import Footer from '../components/footer'
import Home from '../screens/home/home'
import Header from '../components/header'
import Profile from '../screens/home/Profile'
import Popularq from '../screens/home/popularq'
import About from '../screens/home/about'
import Carousal from '../screens/home/carousal'
import Signup from '../screens/loginflow/signup'
import Login from '../screens/loginflow/login'
import ForgetPassword from '../screens/loginflow/forgetPassword'

//    links 
import Aboutus from '../screens/links/aboutus'
import Contactus from '../screens/links/contactus'
import Faqq from '../screens/links/faqq'

import Pricingplans from "../screens/links/pricingplans"
import Cart from '../screens/addtocart/cart'
import Payment from '../screens/addtocart/payment'

import Buttonslayout from '../screens/model/buttonslayout'
import Slider from '../components/slider'
import Startstuding from '../screens/loginflow/startstuding'
import Exampage from '../screens/loginflow/exampage'
import Personalinfo from '../screens/myaccount/personalinfo'
import Changepass from '../screens/myaccount/changepass'
import Subcribeexam from '../screens/loginflow/subscription'
import Resetpassword from '../screens/loginflow/resetpassword'
import Examcard from '../screens/loginflow/exampage'
import VerificationForm from '../screens/loginflow/verificationForm'

export default function publicrouter() {
    return (
        <div>
            <BrowserRouter basename='/secret4exam'>
                <Header />
                <Routes>
                    <Route path='/' element={<Home />} />
                    <Route path='profile' element={<Profile />} />
                    <Route path='popularq' element={<Popularq />} />
                    <Route path='about' element={<About />} />
                    <Route path='carousal' element={<Carousal />} />
                    <Route path='signup' element={<Signup />} />
                    <Route path='login' element={<Login />} />
                    <Route path='aboutus' element={<Aboutus />} />
                    <Route path='contactus' element={<Contactus />} />
                    <Route path='faqq' element={< Faqq />} />
                    <Route path='cart' element={< Cart />} />
                    <Route path='payment' element={< Payment />} />
                    <Route path='exampage' element={< Exampage />} />
                    <Route path='examcard' element={< Examcard />} />
                    <Route path='changepass' element={< Changepass />} />
                    <Route path='personalinfo' element={< Personalinfo />} />
                    <Route path='startstuding' element={< Startstuding />} />
                    <Route path='pricingplans/:id' element={< Pricingplans />} />
                    <Route path='forgetPassword' element={< ForgetPassword />} />
                    <Route path='buttonslayout' element={< Buttonslayout />} />
                    <Route path='Subcribeexam' element={< Subcribeexam />} />
                    <Route path='resetpassword' element={< Resetpassword />} />
                    <Route path='verificationForm' element={< VerificationForm />} />
                </Routes>
                <Footer />
            </BrowserRouter>
        </div>
    )
}




