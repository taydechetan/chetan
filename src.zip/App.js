import React from "react";
import "./App.css";
import PublicRouter from "./router/publicrouter";
import { ToastContainer } from "react-toastify";
import { CartProvider } from "./screens/addtocart/CartContext";
import Pricingplans from "./screens/links/pricingplans";

export default function App() {
  return (
    <CartProvider>
      <div>
        <PublicRouter />
        <ToastContainer />

      </div>
    </CartProvider>
  );
}
