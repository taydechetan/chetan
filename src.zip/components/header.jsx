import React, { useState, useEffect } from "react";
import "./Header.css";
import { CiMail } from "react-icons/ci";
import { IoSearch } from "react-icons/io5";
import { FiMenu } from "react-icons/fi";
import { Offcanvas } from "react-bootstrap";
import { Link, useNavigate } from "react-router-dom";
import { apiCallNew } from "../networkcall/apiservises";
import ApiEndPoints from "../networkcall/Apiendpoint";
import { setUserData, setToken, getUserdata, Logout } from "../helper/storage";
import { useCart } from "../screens/addtocart/CartContext";
import { FaShoppingBag } from "react-icons/fa";
import { FaWhatsapp } from "react-icons/fa6";
import { FaLocationDot } from "react-icons/fa6";

const Header = () => {
  const navigate = useNavigate();
  const { cartdata } = useCart();
  const [show, setShow] = useState(false);
  const [data, setData] = useState([]);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [user, setUser] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");

  const toggleSidebar = async () => {
    setShow(!show);
    if (!show) {
      try {
        const response = await apiCallNew("get", null, ApiEndPoints.CateList);
        if (response.code === 200) {
          setData(response.result);
        } else {
          console.log("Failed to fetch data: ", response.status);
        }
      } catch (error) {
        console.error("Error fetching categories:", error);
      }
    }
  };

  const checkUserLoginStatus = async () => {
    const userData = await getUserdata();
    if (userData) {
      setIsLoggedIn(true);
      setUser(userData.Student);
    }
  };

  const handleLogout = async () => {
    await Logout();
    setIsLoggedIn(false);
    setUser(null);
    navigate("/");
  };

  useEffect(() => {
    checkUserLoginStatus();
  }, []);

  const passData = (id) => {
    navigate(`/pricingplans/${id}`);
    toggleSidebar();
  };

  const filteredData = data.filter((item) =>
    item.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div>
      <div className="Header-section">
        <nav className="navbar navbar-expand-lg navbar-light">
          <div className="container d-flex justify-content-between align-items-center">
            <div className="d-none d-lg-flex">
              <ul className="navbar-nav me-auto mb-2 mb-lg-0 d-flex align-items-center">
                <li className="nav-item me-4">
                  <a
                    href="mailto:info@secrets4exams.com"
                    className="icon"
                    style={{ color: "white" }}
                  >
                    <CiMail className="icon-email fs-4" />
                    <span className="ms-2" style={{ fontSize: "15px" }}>
                      <a
                        href="https://mail.google.com/mail/?view"
                        target="_blank"
                        style={{ textDecoration: "none", color: "white" }}
                      >
                        info@secrets4exams.com
                      </a>
                    </span>
                  </a>
                </li>
                <li className="nav-item mt-3">
                  <p href="#" className="icon" style={{ color: "white" }}>
                    <FaLocationDot className="icon-location"  style={{fontSize:"15px"}}/>
                    <span className="ms-2" style={{ fontSize: "14px" }}>
                      UAE
                    </span>
                  </p>
                </li>
              </ul>
            </div>
            <div className="whatsapp-icon d-flex justify-content-center">
              <a
                href="https://web.whatsapp.com/"
                target="_blank"
                style={{ fontSize: "20px", color: "white" }}
              >
                <FaWhatsapp />
              </a>
            </div>
          </div>
        </nav>
      </div>

      <div className="header-second secondslider-cnt">
        <div className="bg-light py-2">
          <nav className="container-fluid d-flex justify-content-between align-items-center">
            <a href="./" className="navbar-brand">
              <Link to={"./"}>
                <img
                  src="https://www.secrets4exams.com/images/logo/logo_1705643891logo%20(3).png"
                  alt="img"
                />
              </Link>
            </a>
            <div className="header-buttons d-flex align-items-center">
              <div className="d-none d-md-flex">
                {!isLoggedIn ? (
                  <>
                    <Link to="/login" className="custom-loginn">
                      <button className="custom-login">Login</button>
                    </Link>
                    <Link to="./signup" className="newsnm">
                      <button className="custom-login">Signup</button>
                    </Link>
                  </>
                ) : (
                  <>
                    <button className="custom-login" onClick={handleLogout}>
                      Logout
                    </button>
                    <Link to="/Startstuding" className="newsnm">
                      <button className="custom-login">Start Studying</button>
                    </Link>
                  </>
                )}
              </div>

              <div className="d-flex">
                <IoSearch
                  className="fs-4 text-success search-icon mx-4"
                  onClick={toggleSidebar}
                />

                <div className="position-relative shopping-bag mx-4">
                  <Link to="/cart">
                    <FaShoppingBag className="fs-4 text-success" />

                    <span className="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-primary">
                      {cartdata}
                    </span>
                  </Link>
                </div>

                <a href="#" onClick={toggleSidebar}>
                  <FiMenu className="fs-4 text-success menu-icon mx-4" />
                </a>
              </div>
            </div>
          </nav>
        </div>

        <div
          className="thisdd ms-3 mx-3 mt-2 mb-3 d-flex d-md-none"
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
          }}
        >
          {!isLoggedIn ? (
            <>
              <Link
                to="/login"
                className="secretlogn"
                style={{ width: "45%", textDecoration: "none" }}
              >
                <button
                  className="loginbtnsew button-style"
                  style={{
                    width: "100%",
                    height: "40px",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  Login
                </button>
              </Link>

              <Link
                to="/signup"
                className="secretsign ms-2"
                style={{ width: "45%", textDecoration: "none" }}
              >
                <button
                  className="signupbtnsew button-style"
                  style={{
                    width: "100%",
                    height: "40px",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  Sign Up
                </button>
              </Link>
            </>
          ) : (
            <>
              <button
                className="custom-login"
                onClick={handleLogout}
                style={{ width: "45%", height: "40px", fontSize: "14px" }}
              >
                Logout
              </button>
              <Link
                to="/Startstuding"
                className="newsnm"
                style={{ width: "45%", textDecoration: "none" }}
              >
                <button
                  className="custom-login"
                  style={{ width: "100%", height: "40px", fontSize: "14px" }}
                >
                  Start Studying
                </button>
              </Link>
            </>
          )}
        </div>
      </div>

      <div>
        <Offcanvas
          show={show}
          onHide={toggleSidebar}
          placement="end"
          className="sliderrisponsive"
        >
          <Offcanvas.Header closeButton style={{ backgroundColor: "#e1e1e1" }}>
            <Offcanvas.Title>
              <input
                type="text"
                placeholder="Search"
                className="togglebar-input"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
              <IoSearch
                style={{ position: "absolute", top: "28px", left: "28px" }}
              />
            </Offcanvas.Title>
          </Offcanvas.Header>
          <Offcanvas.Body className="togglebar-body">
            {isLoggedIn && user ? (
              <div
                className="user-info"
                style={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                }}
              >
                <h5>{user.name}!</h5>
                <Link to="/personalinfo">
                  <button
                    className="btn btn-primary mt-2"
                    style={{
                      backgroundColor: "#44bd79",
                      color: "white",
                      border: "1px solid #44bd79",
                    }}
                    onClick={toggleSidebar}
                  >
                    My Account
                  </button>
                </Link>
              </div>
            ) : (
              ""
            )}
            <div className="togglebar-content">
              <ul className="togglebar-list">
                {filteredData.map((item, index) => (
                  <li
                    key={index}
                    className="togglebar-item"
                    onClick={() => passData(item.category_id)}
                  >
                    {item.title}
                  </li>
                ))}
              </ul>
            </div>
          </Offcanvas.Body>
        </Offcanvas>
      </div>
    </div>
  );
};

export default Header;
