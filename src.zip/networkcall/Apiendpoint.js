const APPConfig = {
    API_URL: "http://nodejs.aercjbp.com",
    API_URLWWWS: "https://www.secrets4exams.com/api",
    API_URLSS: "http://173.212.250.62/secrets4exams2/public/api",
    API_URLS: "https://api-m.sandbox.paypal.com/",
    API_URLSTEST: "https://www.secrets4exams.com/api/qbank-prev-session/",
    SANDBOX_URL: "https://api-m.sandbox.paypal.com"
};

const ApiEndPoints = {
    Login: `${APPConfig.API_URL}/login`,
    Register: `${APPConfig.API_URL}/register`,
    Faqq: `${APPConfig.API_URL}/faq`,
    ForgetPassword: `${APPConfig.API_URL}/forgetPassword`,
    CateList: `${APPConfig.API_URLSS}/categories-list`,
    About: `${APPConfig.API_URL}/home-about`,
    Aboutus: `${APPConfig.API_URL}/home-about`,
    PackageList: `${APPConfig.API_URLSS}/packages-list/`,
    startStudying: `${APPConfig.API_URL}/startStudying`,
    AddtoCart: `${APPConfig.API_URL}/add-cart`,
    Remove: `${APPConfig.API_URLS}/remove-from-cart`,
    Carousal: `${APPConfig.API_URL}/testimonial-list`,
    CartList: `${APPConfig.API_URL}/cart-data/`,
    RemoveCart: `${APPConfig.API_URL}/remove-from-cart/`,
    Paypal: `${APPConfig.API_URLS}/SandBox`,
    Contactus: `${APPConfig.API_URL}/contact-us`,
    Changepass: `${APPConfig.API_URL}/change-password`,
    subscriptionPackage: `${APPConfig.API_URL}/subscriptionPackage`,
    Example: `${APPConfig.API_URLWWWS}/qbank-prev-session?user_id=88`,
    Examsetion: `${APPConfig.SANDBOX_URL}/test-result/`,
    OrderUrl: `${APPConfig.API_URLS}/create-order`,
    OrderPayment: `${APPConfig.API_URL}/create-payment`,
    CapturUrl: `${APPConfig.API_URLS}/capture-payment/`,
    ResetPassword: `${APPConfig.API_URLS}/resetPassword`,
    VerifyOtp: `${APPConfig.API_URL}/verifyOtp`,
    UpdateProfile: `${APPConfig.API_URL}/getUserById/`,
};

export default ApiEndPoints;

